import dashboard from './dashboard';
import otherPages from './page2';

const withOutC2MenuItems = {
  items: [dashboard, otherPages]
}

export default withOutC2MenuItems;
