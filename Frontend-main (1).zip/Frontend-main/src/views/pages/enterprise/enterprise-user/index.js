import React from 'react'

const EnterpriseUser = () => {
  return (
    <div>EnterpriseUser</div>
  )
}

export default EnterpriseUser